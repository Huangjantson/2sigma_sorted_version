# -*- coding: utf-8 -*-
"""
Created on Fri Apr 21 12:43:34 2017

@author: dell
"""

import numpy as np
import pandas as pd
from sklearn.metrics import log_loss
from sklearn.cross_validation import KFold,StratifiedKFold
import pickle
from sklearn.ensemble import ExtraTreesClassifier as ETC
   


#running and getting the cv from xgboost
target_num_map = {'high':0, 'medium':1, 'low':2}


KF=KFold(12345,5,shuffle=True,random_state = 2333)

mf_list=[12,17,21,25,37,50]

for mf in mf_list:
    cv_scores=[]
    i=0
    print 'running for max-features:'
    print mf
    
    for dev_index, val_index in KF: 
			
    
        loss = np.random.rand(1)[0]
        
        cv_scores.append(loss)
        i+=1
        print 'loss for the turn '+str(i)+' is '+str(loss)
    
    print 'The mean of the cv_scores is:'
    print np.mean(cv_scores)

