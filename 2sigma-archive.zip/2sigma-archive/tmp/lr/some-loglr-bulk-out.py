# -*- coding: utf-8 -*-
"""
Created on Tue Apr 25 09:38:30 2017

@author: dell
"""

import numpy as np
import pandas as pd
from sklearn.metrics import log_loss
from sklearn.cross_validation import StratifiedKFold
import pickle


"""data for l1 and l2 lr"""

from sklearn.linear_model import LogisticRegression

"""data for log lr"""
data_path = "/home/raku/kaggleData/2sigma/loglr/"
store_lg= "/home/raku/kaggleData/2sigma/loglrC03/"
train_file = data_path + "loglr-n-train.json"
test_file = data_path + "loglr-n-test.json"
train_df = pd.read_json(train_file)
test_df = pd.read_json(test_file)
print train_df.shape
print test_df.shape

feature_file = data_path+'loglrfeatures.pickle'
fileObject = open(feature_file,'r') 
features = pickle.load(fileObject)
fileObject.close()
print len(features)

#running and getting the cv from xgboost
target_num_map = {'high':0, 'medium':1, 'low':2}
train_y = np.array(train_df['interest_level'].apply(lambda x: target_num_map[x]))
KF=StratifiedKFold(train_y,5,shuffle=True,random_state = 2333)

"""trainX testX for et and rf """
train_X, test_X = train_df[features].as_matrix(), test_df[features].as_matrix()

lr = LogisticRegression(penalty='l2',C=0.3)
lr.fit(train_X,train_y)
preds = lr.predict_proba(test_X)

out_df = pd.DataFrame(preds)
out_df.columns = ["high", "medium", "low"]
out_df["listing_id"] = test_df.listing_id.values
out_df.to_json(store_lg+'loglrC03-bulk-out.json')



