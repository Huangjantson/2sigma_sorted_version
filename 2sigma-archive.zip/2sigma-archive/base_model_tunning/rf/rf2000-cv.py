# -*- coding: utf-8 -*-
"""
Created on Fri Apr 21 12:43:34 2017

@author: dell
"""

import numpy as np
import pandas as pd
from sklearn.metrics import log_loss
from sklearn.cross_validation import KFold,StratifiedKFold
import pickle
from sklearn.ensemble import RandomForestClassifier as RFC
    
#lodaing data
data_path = "/home/raku/kaggleData/2sigma/xgb142/"
store = "/home/raku/kaggleData/2sigma/xgb142/"
train_file = data_path + "xgb1.42-train.json"
test_file = data_path + "xgb1.42-test.json"
train_df = pd.read_json(train_file)
test_df = pd.read_json(test_file)
print(train_df.shape)
print(test_df.shape)

feature_file = data_path+'xgb142features.pickle'
fileObject = open(feature_file,'r') 
features = pickle.load(fileObject)
fileObject.close()

# In[17]:

#running and getting the cv from xgboost
target_num_map = {'high':0, 'medium':1, 'low':2}

train_y = np.array(train_df['interest_level'].apply(lambda x: target_num_map[x]))

KF=StratifiedKFold(train_y,5,shuffle=True,random_state = 2333)

#mf_list=[12,17,21,25,37,50]
mf_list=[70,100]

for mf in mf_list:
    cv_scores=[]
    i=0
    print 'running for max-features:'
    print mf
    
    for dev_index, val_index in KF: 
        result_dict = {}
        
        dev_set, val_set = train_df.iloc[dev_index,:] , train_df.iloc[val_index,:] 
           #filter the features
        dev_X, val_X = dev_set[features].as_matrix(), val_set[features].as_matrix()
        dev_y, val_y = train_y[dev_index], train_y[val_index]
        
        rf = RFC(200,max_features=mf)
        rf.fit(dev_X,dev_y)
        preds = rf.predict_proba(val_X)
    
        loss = log_loss(val_y, preds)
        
        cv_scores.append(loss)
        i+=1
        print 'loss for the turn '+str(i)+' is '+str(loss)
    
    print 'The mean of the cv_scores is:'
    print np.mean(cv_scores)


# In[17]:

"""
run for testing


train_X, test_X = train_df[features].as_matrix(), test_df[features].as_matrix()

preds, model = runXGB(train_X, train_y, test_X,\
feature_names=features,
num_rounds = 3800, eta = 0.02,max_depth = 4,verbose_eval=100)

out_df = pd.DataFrame(preds)
out_df.columns = ["high", "medium", "low"]
out_df.to_json(store+'xgb142-bulk-out.json')
out_df["listing_id"] = test_df.listing_id.values
out_df.to_csv("xgb_beta1point42-0.02.csv", index=False)
"""
