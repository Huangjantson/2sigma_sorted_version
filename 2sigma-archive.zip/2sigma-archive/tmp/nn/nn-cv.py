import pandas as pd
import numpy as np
import pickle
from sklearn.metrics import log_loss
from sklearn.cross_validation import KFold

from keras.models import Sequential
from keras.layers import Dense, Dropout
from keras.regularizers import l2
from keras import optimizers
from keras.callbacks import EarlyStopping

data_path = '/home/raku/kaggleData/2sigma/lr4/'

train_df=pd.read_json(data_path+'lr4-n-train.json')
test_df=pd.read_json(data_path+'lr4-n-test.json')

pickl_file = '/home/raku/kaggleData/2sigma/loglr/'+'loglrfeatures.pickle'
fileObject = open(pickl_file,'r') 
features=pickle.load(fileObject)   
fileObject.close()
print len(features)

def nn_model(features,num_classes=3,lr=0.1):
    model = Sequential()
    model.add(Dense(64,  
                    activation='softplus',
                    input_shape = (len(features),),
                                  kernel_initializer='he_normal',
                                  kernel_regularizer=l2(0.000025)
                                  ))
    model.add(Dropout(0.2))
    
    model.add(Dense(16,
                    activation='softplus', 
                    kernel_initializer='he_normal',
                    kernel_regularizer=l2(0.000025)
                    ))
    model.add(Dropout(0.1))

    model.add(Dense(units=num_classes, 
                    activation='softmax', 
                    kernel_initializer='he_normal',
                    ))
    opt = optimizers.Adadelta(lr=1)
    model.compile(loss='sparse_categorical_crossentropy', 
                  optimizer=opt,
                  metrics=['accuracy']
                  )
    return(model)
    
#prepare for training
target_num_map = {'high':0, 'medium':1, 'low':2}

train_y = np.array(train_df['interest_level'].apply(lambda x: target_num_map[x]))

KF=KFold(len(train_df),5,shuffle=True,random_state = 2333)

for batch_size in [64,128,256]:
#first edition:
#numericals from xgb142 + some new hcc encoding + with_feat from xgb142
    cv_scores=[]
    for dev_index, val_index in KF:
        dev_set, val_set = train_df.iloc[dev_index,:] , train_df.iloc[val_index,:] 
        dev_X, val_X = dev_set[features].as_matrix(), val_set[features].as_matrix()
        dev_y, val_y = train_y[dev_index], train_y[val_index]
    
        early_stopping = EarlyStopping(monitor='val_loss', patience=20)

        seed = 0
        np.random.seed(seed)
        model = nn_model(features,lr=0.1)
        model.fit(dev_X, dev_y, epochs = 1000, batch_size=batch_size, verbose = 2, 
          validation_data=[val_X, val_y], callbacks=[early_stopping])

        preds =  model.predict_proba(val_X)
        
        cv_scores.append(log_loss(val_y, preds))
        
        print(cv_scores)
    
    print np.mean(cv_scores)

