import numpy as np
import pandas as pd
from sklearn.metrics import log_loss
from sklearn.cross_validation import StratifiedKFold
import pickle


"""data for l1 and l2 lr"""

from sklearn.linear_model import LogisticRegression

data_path = "/home/raku/kaggleData/2sigma/lr4/"
store_l1= "/home/raku/kaggleData/2sigma/lrl1C1/"
store_l2="/home/raku/kaggleData/2sigma/lrl2C3/"
train_file = data_path + "lr4-n-train.json"
test_file = data_path + "lr4-n-test.json"
train_df = pd.read_json(train_file)
test_df = pd.read_json(test_file)
print train_df.shape
print test_df.shape

#running and getting the cv from xgboost
target_num_map = {'high':0, 'medium':1, 'low':2}
train_y = np.array(train_df['interest_level'].apply(lambda x: target_num_map[x]))
KF=StratifiedKFold(train_y,5,shuffle=True,random_state = 2333)

feature_file = data_path+'lr4features.pickle'
fileObject = open(feature_file,'r') 
features = pickle.load(fileObject)
fileObject.close()
print len(features)


train_X, test_X = train_df[features].as_matrix(), test_df[features].as_matrix()

#for the l1 model

lr = LogisticRegression(penalty='l1',C=1)
lr.fit(train_X,train_y)
preds = lr.predict_proba(test_X)

out_df = pd.DataFrame(preds)
out_df.columns = ["high", "medium", "low"]
out_df["listing_id"] = test_df.listing_id.values
out_df.to_json(store_l1+'lrl1C1-bulk-out.json')

#for the l2 model
lr = LogisticRegression(penalty='l2',C=3)
lr.fit(train_X,train_y)
preds = lr.predict_proba(test_X)

out_df = pd.DataFrame(preds)
out_df.columns = ["high", "medium", "low"]
out_df["listing_id"] = test_df.listing_id.values
out_df.to_json(store_l2+'lrl2C3-bulk-out.json')

