# -*- coding: utf-8 -*-
"""
Created on Tue Apr 25 09:38:30 2017

@author: dell
"""

import numpy as np
import pandas as pd
from sklearn.metrics import log_loss
from sklearn.cross_validation import StratifiedKFold
import pickle
from sklearn.ensemble import ExtraTreesClassifier as ETC
from sklearn.ensemble import RandomForestClassifier as RFC
    
#lodaing data
"""data and datapath for et and rf"""
data_path = "/home/raku/kaggleData/2sigma/xgb142/"
store_et = "/home/raku/kaggleData/2sigma/et1000mf140/"
store_rf = "/home/raku/kaggleData/2sigma/rf1000mf70/"

train_file = data_path + "xgb1.42-train.json"
test_file = data_path + "xgb1.42-test.json"
train_df = pd.read_json(train_file)
test_df = pd.read_json(test_file)
print train_df.shape
print test_df.shape

feature_file = data_path+'xgb142features.pickle'
fileObject = open(feature_file,'r') 
features = pickle.load(fileObject)
fileObject.close()


#running and getting the cv from xgboost
target_num_map = {'high':0, 'medium':1, 'low':2}
train_y = np.array(train_df['interest_level'].apply(lambda x: target_num_map[x]))
KF=StratifiedKFold(train_y,5,shuffle=True,random_state = 2333)

#cv out for et
cv_scores=[]
i=0
for dev_index, val_index in KF: 
    result_dict = {}
    
    dev_set, val_set = train_df.iloc[dev_index,:] , train_df.iloc[val_index,:] 
       #filter the features
    dev_X, val_X = dev_set[features].as_matrix(), val_set[features].as_matrix()
    dev_y, val_y = train_y[dev_index], train_y[val_index]
    
    et = ETC(1000,max_features=140)
    et.fit(dev_X,dev_y)
    preds = et.predict_proba(val_X)

    loss = log_loss(val_y, preds)
    
    #save the pickles for futures use
    pickl_file = store_et+'et1000mf140-5fold-out-'+str(i)+'.pickle'
    fileObject = open(pickl_file,'wb') 
    pickle.dump(preds,fileObject)   
    fileObject.close()    
    
    cv_scores.append(loss)
    i+=1
    print 'loss for the turn '+str(i)+' is '+str(loss)

print 'The mean of the cv_scores is:'
print np.mean(cv_scores)

#cv out for rf
cv_scores=[]
i=0
for dev_index, val_index in KF: 
    result_dict = {}
    
    dev_set, val_set = train_df.iloc[dev_index,:] , train_df.iloc[val_index,:] 
       #filter the features
    dev_X, val_X = dev_set[features].as_matrix(), val_set[features].as_matrix()
    dev_y, val_y = train_y[dev_index], train_y[val_index]
    
    rf = RFC(1000,max_features=70)
    rf.fit(dev_X,dev_y)
    preds = rf.predict_proba(val_X)

    loss = log_loss(val_y, preds)
    
    #save the pickles for futures use
    pickl_file = store_rf+'rf1000mf70-5fold-out-'+str(i)+'.pickle'
    fileObject = open(pickl_file,'wb') 
    pickle.dump(preds,fileObject)   
    fileObject.close()    
    
    cv_scores.append(loss)
    i+=1
    print 'loss for the turn '+str(i)+' is '+str(loss)

    
"""trainX testX for et and rf """
train_X, test_X = train_df[features].as_matrix(), test_df[features].as_matrix()

et = ETC(1000,max_features=140)
et.fit(train_X,train_y)
preds = et.predict_proba(test_X)

out_df = pd.DataFrame(preds)
out_df.columns = ["high", "medium", "low"]
out_df["listing_id"] = test_df.listing_id.values
out_df.to_json(store_et+'et1000mf140-bulk-out.json')

#============================================

rf = RFC(1000,max_features=70)
rf.fit(train_X,train_y)
preds = rf.predict_proba(test_X)

out_df = pd.DataFrame(preds)
out_df.columns = ["high", "medium", "low"]
out_df["listing_id"] = test_df.listing_id.values
out_df.to_json(store_rf+'rf1000mf70-bulk-out.json')

"""data for l1 and l2 lr"""

from sklearn.linear_model import LogisticRegression

data_path = "/home/raku/kaggleData/2sigma/lr4/"
store_l1= "/home/raku/kaggleData/2sigma/lrl1C1/"
store_l2="/home/raku/kaggleData/2sigma/lrl2C3/"
train_file = data_path + "lr4-n-train.json"
test_file = data_path + "lr4-n-test.json"
train_df = pd.read_json(train_file)
test_df = pd.read_json(test_file)
print train_df.shape
print test_df.shape

feature_file = data_path+'lr4features.pickle'
fileObject = open(feature_file,'r') 
features = pickle.load(fileObject)
fileObject.close()
print len(features)

"""trainX testX for et and rf """
train_X, test_X = train_df[features].as_matrix(), test_df[features].as_matrix()

#for the l1 model

lr = LogisticRegression(penalty='l1',C=1)
lr.fit(train_X,train_y)
preds = lr.predict_proba(test_X)

out_df = pd.DataFrame(preds)
out_df.columns = ["high", "medium", "low"]
out_df["listing_id"] = test_df.listing_id.values
out_df.to_json(store_l1+'lrl1C1-bulk-out.json')

#for the l2 model
lr = LogisticRegression(penalty='l2',C=3)
lr.fit(train_X,train_y)
preds = lr.predict_proba(test_X)

out_df = pd.DataFrame(preds)
out_df.columns = ["high", "medium", "low"]
out_df["listing_id"] = test_df.listing_id.values
out_df.to_json(store_l2+'lrl2C3-bulk-out.json')

"""data for log lr"""
data_path = "/home/raku/kaggleData/2sigma/loglr/"
store_lg= "/home/raku/kaggleData/2sigma/loglrC03/"
train_file = data_path + "loglr-n-train.json"
test_file = data_path + "loglr-n-test.json"
train_df = pd.read_json(train_file)
test_df = pd.read_json(test_file)
print train_df.shape
print test_df.shape

"""trainX testX for et and rf """
train_X, test_X = train_df[features].as_matrix(), test_df[features].as_matrix()

lr = LogisticRegression(penalty='l2',C=0.3)
lr.fit(train_X,train_y)
preds = lr.predict_proba(test_X)

out_df = pd.DataFrame(preds)
out_df.columns = ["high", "medium", "low"]
out_df["listing_id"] = test_df.listing_id.values
out_df.to_json(store_lg+'loglrC03-bulk-out.json')



